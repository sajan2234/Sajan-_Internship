package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.JavascriptExecutor;

public class Customer {

	WebDriver driver;
		@FindBy (name="email")
		private WebElement email;
	
		@FindBy(name="password")
		private WebElement pass;
		
		@FindBy(xpath="//span[contains(text(),'Login')]")
		private WebElement login;
		@FindBy(css=".sidebar-menu [href='https://phptravels.net/account/bookings']")
		private WebElement bookings;
		@FindBy(xpath="//li[@class='user_wallet ']/a[contains(.,'Add Funds')]")
		private WebElement addfunds;
		@FindBy(xpath="//ul[@class='sidebar-menu list-items']//a[contains(.,'My Profile')]")
		private WebElement myprofile;
		@FindBy(xpath="//ul[@class='sidebar-menu list-items']//a[contains(.,'Logout')]")
		private WebElement logout;
		@FindBy(id="gateway_paypal")
		private WebElement paymentwithpaypal;
		@FindBy(xpath="//button[@class='btn btn-primary btn-block btn-lg my-3 waves-effect']")
		private WebElement paynow;
		@FindBy(xpath="//div[@class='btn-front']")
		private WebElement backtoinvoice;
		@FindBy(xpath="//a[.='Yes']")
		private WebElement yes;
		@FindBy(css=".la-eye")
		private WebElement viewvoucher;
		@FindBy(name="address1")
		private WebElement address;
		@FindBy(css="[type='submit']")
		private WebElement updateprofile;
	public Customer(WebDriver driver)	
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void setUsername(String strUserName)
	{
		email.sendKeys(strUserName);
	}
	
	public void setPassword(String strPassword)
	{
		pass.sendKeys(strPassword);
	}
	
	public void clickLogin()
	{
		login.click();
	}
	
	
	
public void bookings()
{
	bookings.click();
}
public void addfunds()
{
	addfunds.click();
}
public void myprofile()
{
	myprofile.click();
}
public void logout()
{
	logout.click();
}
public void paymentwithpaypal()
{
	paymentwithpaypal.click();
}
public void paynow()
{
	paynow.click();
}
public void backtoinvoice()
{
	backtoinvoice.click();
}
public void yes()
{
	yes.click();
}
public void viewvoucher()
{
	viewvoucher.click();
}
public void address(String straddress)
{   address.clear();
	address.sendKeys(straddress);
}
public void updateprofile()
{
	updateprofile.click();
}
public void ScrollDown()
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("arguments[0].scrollIntoView();",paymentwithpaypal);
}
public void ScrollDownprofile()
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("arguments[0].scrollIntoView();",updateprofile);
}
}

