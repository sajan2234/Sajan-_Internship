package pagefactory;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Admin {
	WebDriver driver;
	@FindBy (xpath="//input[@name='email']")
	private WebElement email;
	@FindBy(xpath="//input[@name='password']")
	private WebElement pass;
	@FindBy(xpath="//span[(text()='Login')]")
	private WebElement login;
	@FindBy(xpath="//a[text()='Bookings']")
	private WebElement bookings;
	@FindBy(xpath="//a[contains(text(),'Website')]")
	private WebElement website;
	@FindBy(xpath="//div[@class='card card-raised border-start border-info border-4 confirmed_']//div[@class='d-flex justify-content-between align-items-center mb-2']")
	private WebElement confirmedbookings;
	@FindBy(xpath="//div[@class='card card-raised border-start border-warning border-4 pending_']//div[@class='d-flex justify-content-between align-items-center mb-2']")
	private WebElement pendingbookings;
	@FindBy(xpath="//div[@class='card card-raised border-start border-danger border-4 cancelled_']//div[@class='d-flex justify-content-between align-items-center mb-2']")
	private WebElement cacelledbookings;
	@FindBy(xpath="//select[@id='booking_status']//child::option[text()='Confirmed']")
	private WebElement confirmed;
	@FindBy(xpath="//select[@id='booking_status']//child::option[text()='pending']")
	private WebElement pending;
	@FindBy(xpath="//select[@id=\"booking_status\"]//child::option[contains(text(),'Cancelled')]")
	private WebElement cancelled;
	@FindBy(xpath="//select[@id=\"payment_status\"]//child::option[contains(text(),'paid')]")
	private WebElement paid;
	@FindBy(xpath="//i[@class='fa fa-file']")
	private WebElement invoice;
	@FindBy(xpath="//button[@class='btn btn-danger mdc-ripple-upgraded']")
	private WebElement deletebookings;
	@FindBy(css=".text-uppercase")
	private WebElement dashboardclick;
	@FindBy(xpath="//div[@class='card card-raised border-start border-info border-4 confirmed_']//div[@class='display-5']")
	private WebElement count;
	public Admin(WebDriver driver)	
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void setUsername(String strUserName)
	{
		email.sendKeys(strUserName);
	}
	
	public void setPassword(String strPassword)
	{
		pass.sendKeys(strPassword);
	}
	
	public void clickLogin()
	{
		login.click();
	}
public void bookings()
{bookings.click();
}

public void confirmedbookings()
{confirmedbookings.click();
}
public void pendingbookings()
{pendingbookings.click();
}
public void cacelledbookings()
{cacelledbookings.click();
}
public void website()
{website.click();
}
public void confirmed()
{confirmed.click();
}
public void pending()
{pending.click();
}
public void cancelled()
{cancelled.click();
}
public void paid()
{paid.click();
}
public void invoice()
{invoice.click();
}
public void deletebookings()
{deletebookings.click();
}
public void dashboardclick()
{dashboardclick.click();
}
public String count()
{return count.getText();
}
public void ScrollDownpending()
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("arguments[0].scrollIntoView();",pending);
}
public void ScrollDown()
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("arguments[0].scrollIntoView();",deletebookings);
}
public void Scroll()
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("arguments[0].scrollIntoView();",invoice);
}
}
