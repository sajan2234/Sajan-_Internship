package pagefactory;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Agent {
	WebDriver driver;
	@FindBy (name="email")
	private WebElement email;

	@FindBy(name="password")
	private WebElement pass;
	@FindBy(xpath="//span[contains(text(),'Login')]")
	private WebElement login;
	
	@FindBy(xpath="//li[@class='page-active']/a[contains(.,'My Bookings')]")
	private WebElement mybookings;
	@FindBy(xpath="//li[@class='user_wallet ']/a[contains(.,'Add Funds')]")
	private WebElement addfunds;
	@FindBy(xpath="//ul[@class='sidebar-menu list-items']//a[contains(.,'My Profile')]")
	private WebElement myprofile;
	@FindBy(xpath="//ul[@class='sidebar-menu list-items']//a[contains(.,'Logout')]")
	private WebElement logout;
	@FindBy(xpath="//a[contains(text(),'Hotels')]")
	private WebElement hotels;
	@FindBy(xpath="//a[contains(text(),'flights')]")
	private WebElement flights;
	@FindBy(xpath="//a[contains(text(),'Tours')]")
	private WebElement tours;
	@FindBy(xpath="//a[contains(text(),'visa')]")
	private WebElement visa;
	@FindBy(xpath="//a[contains(text(),'Blog')]")
	private WebElement blog;
	@FindBy(xpath="//a[contains(text(),'Offers')]")
	private WebElement offers;
	@FindBy(xpath="//div[@class='logo']//img[@alt='logo']")
	private WebElement destinationpage;
	@FindBy(id="select2-hotels_city-container")
	private WebElement cityname;
	@FindBy(css=".select2-results__option")
	private WebElement citynameresult;
	@FindBy(id="submit")
	private WebElement searchcity;
	@FindBy(id="currency")
	private WebElement usd;
	@FindBy(xpath="//a[contains(text(),'INR')]")
	private WebElement inr;
	public Agent(WebDriver driver)	
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void setUsername(String strUserName)
	{
		email.sendKeys(strUserName);
	}
	
	public void setPassword(String strPassword)
	{
		pass.sendKeys(strPassword);
	}
	
	public void clickLogin()
	{
		login.click();
	}
	public void addfunds()
	{
		addfunds.click();
}
	public void myprofile()
	{
		myprofile.click();
}
	public void logout()
	{
		logout.click();
}
	public void mybookings()
	{
		mybookings.click();
}
	public void hotels()
	{
		hotels.click();
}
	public void flights()
	{
		flights.click();
}
	public void tours()
	{
		tours.click();
}
	public void visa()
	{
		visa.click();
}
	public void blog()
	{
		blog.click();
}
	public void offers()
	{
		offers.click();
}
	public void destinationpage()
	{
		destinationpage.click();
}
	public void usd()
	{
		usd.click();
}
	public void inr()
	{
		inr.click();
}
	public void setCity(String strcity)
	{
		cityname.click();
		cityname.sendKeys(strcity);
	}	
	public void cityresult()
	{
		citynameresult.click();
}
	public void searchcity()
	{
		searchcity.click();
}
	public void ScrollDown()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();",inr);
	}
	public String getinr()
	{
		return usd.getText();
}}