 package pagefactory;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Supplier {
	WebDriver driver;
	@FindBy (name="email")
	private WebElement email;

	@FindBy(name="password")
	private WebElement pass;
	@FindBy(xpath="//span[contains(text(),'Login')]")
	private WebElement login;
	@FindBy(xpath="//h1[text()='Dashboard']")
	private WebElement dashboard;
	@FindBy(xpath="//div[contains(text(),'Sales overview & summary')]")
	private WebElement sales;
	@FindBy(xpath="//h2[text()='Revenue Breakdown 2023']")
	private WebElement revenue;
	@FindBy(xpath="//a[@data-bs-target='#toursmodule']")
	private WebElement tours;
	@FindBy(xpath="//a[contains(text(),' Tours')]")
	private WebElement tour;
	
    @FindBy(xpath="//a[contains(text(),'Manage Tours')]")
	private WebElement managetours;
	@FindBy(xpath="////a[text()='Bookings']")
	private WebElement bookings;
	@FindBy(xpath="//a[contains(text(),'Flight')]")
	private WebElement flight;
	@FindBy(xpath="//a[contains(text(),'Visa')]")
	private WebElement visa;
	@FindBy(xpath="//div[@class='card card-raised border-start border-info border-4 confirmed_']//div[@class='display-5']")
	private WebElement firstcount;
	@FindBy(xpath="//div[@class='card card-raised border-start border-info border-4 confirmed_']/div[@class='card-body px-4']")
	private WebElement confirmedbookings;
	@FindBy(xpath="//div[@class='card card-raised border-start border-warning border-4 pending_']/div[@class='card-body px-4']")
	private WebElement pendingbookings;
	@FindBy(css=".text-uppercase")
	private WebElement dashboardclick;
	@FindBy(xpath="//select[@id='booking_status']//child::option[.='Confirmed']")
	private WebElement confirmed;
	@FindBy(xpath="//select[@id='booking_status']//child::option[.='pending']")
	private WebElement pending;
	public Supplier(WebDriver driver)	
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void setUsername(String strUserName)
	{
		email.sendKeys(strUserName);
	}
	
	public void setPassword(String strPassword)
	{
		pass.sendKeys(strPassword);
	}
	
	public void clickLogin()
	{
		login.click();
	}
	public String salesoverview()
	{return sales.getText();
	}
	public String Dashboardview()
	{
	return dashboard.getText();
	}
	public boolean Revenue()
	{
		return revenue.isDisplayed();
	}
	public boolean Tours()
	{
		return tours.isDisplayed();
	}
	public boolean bookings()
	{
		return bookings.isDisplayed();
	}
	public boolean flight()
	{
		return flight.isDisplayed();
	}
	public boolean visa()
	{
		return visa.isDisplayed();
	}
	public void clicktours() throws InterruptedException
	{tours.click();
	Thread.sleep(5000);
	tour.click();
	Thread.sleep(5000);
	managetours.click();
	
	}
	public void clickbookings()
	{bookings.click();
	}
	public void clickflight()
	{flight.click();
	}
	public void clickvisa()
	{visa.click();
	}
	public void confirmed() {
		
			
			confirmed.click();
		}
	public void Scroll()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();",revenue);
	}
	public String firstcount()
	{
		return firstcount.getText();
	}
	public void confirmedbookings()
	{
		confirmedbookings.click();
	}
	public void pendingbookings()
	{
		pendingbookings.click();
	}
	public void dashboardclick()
	{
		dashboardclick.click();
	}
	public void pending()
	{
		pending.click();
	}
	
	
}
	

