package Utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {
	public static XSSFWorkbook excelWbook;
	public static XSSFSheet excelWsheet;
	
	public static String getCellData(int RowNum,int ColNum) throws IOException
	{
		
		FileInputStream Excel=new FileInputStream(System.getProperty("D:\\javaeclipse\\PhpTravels\\src\\main\\resources\\ExcelUtility.xlsx"));
		excelWbook=new XSSFWorkbook(Excel);
		excelWsheet=excelWbook.getSheetAt(0);
		return excelWsheet.getRow(RowNum).getCell(ColNum).getStringCellValue();
		
		
		
	}
	public static String getIntegerData(int RowNum,int ColNum) throws IOException
	{
		
		FileInputStream Excel=new FileInputStream(System.getProperty("D:/javaeclipse/PhpTravels/src/main/resources/ExcelUtility.xlsx"));
		excelWbook=new XSSFWorkbook(Excel);
		excelWsheet=excelWbook.getSheetAt(0);
		return excelWsheet.getRow(RowNum).getCell(ColNum).getRawValue();
		
		
		
	}

}
