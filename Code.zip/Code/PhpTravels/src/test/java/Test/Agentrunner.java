package Test;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="D:\\javaeclipse\\PhpTravels\\src\\test\\resources\\Feature\\Agentlogin.feature",glue={"StepDefinitions"},
plugin ={"pretty","html:target/Agent/AgentReport","junit:target/Agent/AgentCucumber.xml"}
		)
public class Agentrunner {

}
