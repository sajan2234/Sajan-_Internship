package Test;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="D:\\javaeclipse\\PhpTravels\\src\\test\\resources\\Feature\\Supplierlogin.feature",glue={"StepDefinitions"},
plugin ={"pretty","html:target/Supplier/SupplierReport","junit:target/Supplier/SupplierCucumber.xml"}
		)
public class SupplierRunner {

}
