package Test;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="D:\\javaeclipse\\PhpTravels\\src\\test\\resources\\Feature\\Admin.feature",glue={"StepDefinitions"},
plugin ={"pretty","html:target/Admin/AdminReport","junit:target/Admin/AdminCucumber.xml"}
		)
public class AdminRunner {

}
