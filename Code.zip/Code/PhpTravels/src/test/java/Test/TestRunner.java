package Test;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="D:\\javaeclipse\\PhpTravels\\src\\test\\resources\\Feature\\Customerlogin.feature",glue={"StepDefinitions"},
 plugin ={"pretty","html:target/Customer/CustomerReport","junit:target/Customer/CustomerCucumber.xml"}
		)
public class TestRunner {

}
