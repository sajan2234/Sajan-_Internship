package StepDefinitions;


import static org.junit.Assert.assertEquals;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import pagefactory.Customer;

public class CustomerSteps {
	
	
	
	WebDriver driver=null; 
	Customer user;
	
	@Given("the browser is open")
	public void the_browser_is_open() {
		System.setProperty("webdriver.chrome.driver","D:/javaeclipse/saucedemo/src/test/java/driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Given("the user is on the phptravels login page")
	public void the_user_is_on_the_phptravels_login_page() {
		driver.navigate().to("https://phptravels.net/login");
	}

	@When("user enters invalid email id format  and invalid password")
	public void user_enters_invalid_email_id_format_and_invalid_password() throws IOException {
	   user=new Customer(driver);
	   String A[]= {"userphp","php@gmail.com","php@","demo","demouser"};
	   
		user.setUsername(A[0]);
		user.setPassword(A[3]);
	}

	@When("user clicks login")
	public void user_clicks_login() {
	   user.clickLogin();
	}

	@Then("system should show the error message")
	public void system_should_show_the_error_message() {
		String ActualTitle =driver.getTitle();
		String Expected="Login - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
	
	
	@Given("user is on the phptravels login page")
	public void user_is_on_the_phptravels_login_page() {
		System.setProperty("webdriver.chrome.driver","D:/javaeclipse/saucedemo/src/test/java/driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
	}

	@When("user enters invalid email id and invalid password")
	public void user_enters_invalid_email_id_and_invalid_password() {
		user=new Customer(driver);
		   String A[]= {"userphp","php@gmail.com","php@","demo","demouser"};
		   
			user.setUsername(A[1]);
			user.setPassword(A[3]);
	}

	@When("user clicks login button")
	public void user_clicks_login_button() {
		 user.clickLogin();
	}

	@Then("system should display the error message")
	public void system_should_display_the_error_message() {
		String ActualTitle =driver.getTitle();
		String Expected="Login - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
	
	
	@Given("user is on the phptravels login Page")
	public void user_is_on_the_phptravels_login_Page() {
		System.setProperty("webdriver.chrome.driver","D:/javaeclipse/saucedemo/src/test/java/driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
	}

	@When("user enters incomplete email id and valid password")
	public void user_enters_incomplete_email_id_and_valid_password() {
		user=new Customer(driver);
		   String A[]= {"userphp","php@gmail.com","php@","demo","demouser"};
			user.setUsername(A[2]);
			user.setPassword(A[4]);
	}

	@When("user clicks the login button")
	public void user_clicks_the_login_button() {
		user.clickLogin();
	}

	@Then("system should display  error message")
	public void system_should_display_error_message() {
		String ActualTitle =driver.getTitle();
		String Expected="Login - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
	
	
	@When("user enters valid email id and valid password")
	public void user_enters_valid_email_id_and_valid_password() {
		user=new Customer(driver);
		   String A[]= {"userphp","php@gmail.com","php@","demo","demouser","user@phptravels.com"};
			user.setUsername(A[5]);
			user.setPassword(A[4]);
	}

	@When("user clicks on the login button")
	public void user_clicks_on_the_login_button() {
		user.clickLogin();
	}

	@Then("system should Log into the website")
	public void system_should_log_into_the_website() {
		String ActualTitle =driver.getTitle();
		String Expected="Dashboard - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
		
	}
	
	@Given("user is logged in")
	public void user_is_logged_in() {
		System.setProperty("webdriver.chrome.driver","D:/javaeclipse/saucedemo/src/test/java/driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		System.out.print("user is logged in");
		user=new Customer(driver);
		   String A[]= {"userphp","php@gmail.com","php@","demo","demouser","user@phptravels.com"};
			user.setUsername(A[5]);
			user.setPassword(A[4]);
			user.clickLogin();
	}

	@Then("click on the my bookings")
	public void click_on_the_my_bookings() {
	    user.bookings();
	}

	@Then("verify the functionality")
	public void verify_the_functionality() {
		String ActualTitle =driver.getTitle();
		String Expected="Bookings - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();

	}
	@Then("click on the my profile")
	public void click_on_the_my_profile() {
	    user.myprofile();
	}

	@Then("verify the my profile functionality")
	public void verify_the_my_profile_functionality() {
		String ActualTitle =driver.getTitle();
		String Expected="Profile - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
	@Then("click on the addfunds")
	public void click_on_the_addfunds() {
	    user.addfunds();
	}

	@Then("verify the my addfunds functionality")
	public void verify_the_my_addfunds_functionality() {
		String ActualTitle =driver.getTitle();
		String Expected="Add Funds - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
	@Then("click on the logout")
	public void click_on_the_logout() {
	   user.logout();
	}

	@Then("verify the my logout functionality")
	public void verify_the_my_logout_functionality() {
		String ActualTitle =driver.getTitle();
		String Expected="Login - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
	@Then("the issue voucher is displayed")
	public void the_issue_voucher_is_displayed() throws InterruptedException {
		Thread.sleep(5000);
		user.viewvoucher();
		Thread.sleep(5000);
		String ActualTitle =driver.getTitle();
		String Expected="Hotel Invoice - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		Thread.sleep(5000);
		driver.quit();
	}
	@Then("select the Pay with paypal")
	public void select_the_pay_with_paypal() throws InterruptedException {
		user.ScrollDown();
		Thread.sleep(10000);
	    user.paymentwithpaypal();
	}

	@Then("click on paynow button")
	public void click_on_paynow_button() {
	    user.paynow();
	}

	@Then("verify the payment")
	public void verify_the_payment() throws InterruptedException {
		Thread.sleep(10000);
		String ActualTitle =driver.getTitle();
		String Expected="Payment with paypal";
		assertEquals(ActualTitle,Expected);
	}

	@Then("Click on back to invoice")
	public void click_on_back_to_invoice() throws InterruptedException {
		Thread.sleep(10000);
	    user.backtoinvoice();
	}

	@Then("a message is displayed,'Are you sure'Click on yes")
	public void a_message_is_displayed_are_you_sure_click_on_yes() throws InterruptedException {
		Thread.sleep(10000);
	    user.yes();
	}

	@Then("its redirected to Add Funds page")
	public void its_redirected_to_add_funds_page() throws InterruptedException {
		Thread.sleep(10000);
		String ActualTitle =driver.getTitle();
		String Expected="Add Funds - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
	}

	@Then("Enter the address from the usecases")
	public void enter_the_address_from_the_usecases() throws IOException {
		String B[]={"Covert Villa House Po"};
	    user.address(B[0]);
	}

	@Then("verify the profile is updated successfully")
	public void verify_the_profile_is_updated_successfully() throws InterruptedException {
		Thread.sleep(5000);
	user.ScrollDownprofile();
		Thread.sleep(10000);
	   user.updateprofile();
	   Thread.sleep(10000);
	   
	   //String x=driver.switchTo().alert().getText();
	   //String Expected="Profile updated successfully.";
	   //assertEquals(x,Expected);
	   
	}

}

	
	


