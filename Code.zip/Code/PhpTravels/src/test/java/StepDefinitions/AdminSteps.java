package StepDefinitions;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import pagefactory.Admin;

public class AdminSteps {
	WebDriver driver=null; 
	Admin admin;
	
	@Given("The browser is Opened")
	public void the_browser_is_opened() {
		System.setProperty("webdriver.chrome.driver","D:/javaeclipse/saucedemo/src/test/java/driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@When("I am on the Admin Login page")
	public void i_am_on_the_admin_login_page() {
		driver.navigate().to("https://phptravels.net/api/admin");
		admin=new Admin(driver);
	}

	@Then("Enter the username as {string} and password as {string}")
	public void enter_the_username_as_and_password_as(String string, String string2) {
	    admin.setUsername(string);
	    admin.setPassword(string2);
	}

	@Then("click on the login button in the Admin Page")
	public void click_on_the_login_button_in_the_admin_page() throws InterruptedException {
		Thread.sleep(3000);
	    admin.clickLogin();
	}

	@Then("I validate the login using Assertion")
	public void i_validate_the_login_using_assertion() {
		String ActualTitle =driver.getTitle();
		String Expected="Administator Login";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@Then("Enter the Email as {string} and password as {string}")
	public void enter_the_email_as_and_password_as(String string, String string2) throws InterruptedException {
		 admin.setUsername(string);
		    admin.setPassword(string2);
		    Thread.sleep(3000);
	}

	@Then("I validate the login Functionality using Assertion")
	public void i_validate_the_login_functionality_using_assertion() throws InterruptedException {
		Thread.sleep(3000);
		String ActualTitle =driver.getTitle();
		String Expected="Dashboard";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@Then("the Admin should be logged in")
	public void the_admin_should_be_logged_in() throws InterruptedException {
		admin.setUsername("admin@phptravels.com");
	    admin.setPassword("demoadmin");
	    Thread.sleep(3000);
	    admin.clickLogin();
	    Thread.sleep(5000);
	}

	@Then("I Click on the Bookings Link")
	public void i_click_on_the_bookings_link() {
	    admin.bookings();
	}

	@Then("Booking Details Page is Displayed")
	public void booking_details_page_is_displayed() {
		String ActualTitle =driver.getTitle();
		String Expected="All Bookings View";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("Admin Click on Bookings Link a new page is displayed")
	public void admin_click_on_bookings_link_a_new_page_is_displayed() {
	    admin.bookings();
	}

	@When("click on the View Voucher where payment is successful")
	public void click_on_the_view_voucher_where_payment_is_successful() throws InterruptedException {
		Thread.sleep(3000);
	    admin.confirmedbookings();
	    Thread.sleep(3000);
	    admin.Scroll();
	    Thread.sleep(5000);
	    admin.invoice();
	    Thread.sleep(1000);
	}

	@Then("I should view The Voucher where payment is successful")
	public void i_should_view_the_voucher_where_payment_is_successful() throws InterruptedException {
		Thread.sleep(3000);
		String ActualTitle =driver.getTitle();
		String Expected="Hotel Invoice - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		Thread.sleep(3000);
		driver.quit();
	}

	@When("I Select a record having booking status as Cancelled")
	public void i_select_a_record_having_booking_status_as_cancelled() throws InterruptedException {
		Thread.sleep(3000);
	   admin.cacelledbookings();
	}

	@Then("Click on the delete button of that record")
	public void click_on_the_delete_button_of_that_record() throws InterruptedException {
		admin.ScrollDown();
		Thread.sleep(3000);
	    admin.deletebookings();
	}

	@When("I select a record having Booking Status as Pending")
	public void i_select_a_record_having_booking_status_as_pending() throws InterruptedException {
		Thread.sleep(3000);
	    admin.pendingbookings();
	    
	}

	@Then("I change the Booking status of the Record to confirmed.")
	public void i_change_the_booking_status_of_the_record_to_confirmed() throws InterruptedException {
		admin.ScrollDownpending();
		Thread.sleep(3000);
	    admin.pending();
	    Thread.sleep(3000);
	    admin.confirmed();
	    Thread.sleep(2000);
	}

	@Then("Click on the Confirmed Bookings in the Dashboard")
	public void click_on_the_confirmed_bookings_in_the_dashboard() {
	    admin.confirmedbookings();
	}

	@Then("I verify the count Using Assertion")
	public void i_verify_the_count_using_assertion() {
	    String x=admin.count();
	    System.out.print("The Dashboard Count is"+x);
	}

	@Then("Click on the Website link")
	public void click_on_the_website_link() throws InterruptedException {
	    admin.website();
	    Thread.sleep(3000);
	}

	@Then("Admin should be redirected to a different page")
	public void admin_should_be_redirected_to_a_different_page() throws InterruptedException {
		Thread.sleep(5000);
		String ActualTitle =driver.getTitle();
		String Expected="PHPTRAVELS | Travel Technology Partner - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
}
