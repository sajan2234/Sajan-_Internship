package StepDefinitions;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import pagefactory.Supplier;

public class SupplierSteps {
	WebDriver driver=null;
	Supplier supplier;
	
	@When("the browser is Open")
	public void the_browser_is_open() {
		System.setProperty("webdriver.chrome.driver","D:/javaeclipse/saucedemo/src/test/java/driver/chromedriver.exe");
		driver=new ChromeDriver();
		supplier=new Supplier(driver);
		driver.manage().window().maximize();
	}

	@Then("the user is on Supplier login page")
	public void the_user_is_on_supplier_login_page() {
		driver.navigate().to("https://phptravels.net/supplier");
		supplier=new Supplier(driver);
	}
	@Then("Enter the Supplier email as \"supplier@php\"and supplier password as {string} .")
	public void enter_the_supplier_email_as_supplier_php_and_supplier_password_as(String string) throws InterruptedException {
		supplier.setUsername("supplier@php");
	    supplier.setPassword(string);
	    Thread.sleep(2000);
	}
	

	@Then("Click on the login button")
	public void click_on_the_login_button() throws InterruptedException {
	    supplier.clickLogin();
	    Thread.sleep(3000);
	}

	@Then("I could verify the functionality using Assertion")
	public void i_could_verify_the_functionality_using_assertion() {
		String ActualTitle =driver.getTitle();
		String Expected="Supplier Login";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@Then("Enter the Supplier email as {string}and password as {string}")
	public void enter_the_email_as_supplier_phptravels_com_and_password_as(String string, String string1) {
	    supplier.setUsername(string);
	    supplier.setPassword(string1);	}

	@Then("I should be logged in")
	public void i_should_be_logged_in() {
		String ActualTitle =driver.getTitle();
		String Expected="Dashboard";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@Given("the user is logged in")
	public void the_user_is_logged_in() throws InterruptedException {
		supplier.setUsername("supplier@phptravels.com");
	    supplier.setPassword("demosupplier");
	    Thread.sleep(5000);
	    supplier.clickLogin();
	    Thread.sleep(5000);
	}

	@Then("Check the dashboard view")
	public void check_the_dashboard_view() throws InterruptedException {
		String ActualTitle =supplier.Dashboardview();
		String Expected="Dashboard";
		assertEquals(ActualTitle,Expected);
		Thread.sleep(5000);
	}

	@Then("Check the text Sales overview & summary in the Dashboard")
	public void check_the_text_sales_overview_summary_in_the_dashboard() {
		String ActualTitle =supplier.salesoverview();
		String Expected="Sales overview & summary";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@Given("scrolldown the dashboard")
	public void scrolldown_the_dashboard() {
	    supplier.Scroll();
	}

	@Then("verify the Revenue breakdown using assertion")
	public void verify_the_revenue_breakdown_using_assertion() {
		boolean bool = supplier.Revenue();
		assertEquals(bool,true);
		driver.quit();
	}

	@Then("Click on the Bookings")
	public void click_on_the_bookings() throws InterruptedException {
		Thread.sleep(5000);
		supplier.pendingbookings();
	}

	@Then("Change the status from Pending to Confirmed")
	public void change_the_status_from_pending_to_confirmed() throws InterruptedException {
		
		Thread.sleep(5000);
		supplier.pending();
		Thread.sleep(5000);
	    supplier.confirmed();
	    Thread.sleep(2000);
	    driver.quit();
	}

	

	@Then("verify count in dashboard")
	public void verify_count_in_dashboard() throws InterruptedException {
		String ActualTitle =supplier.firstcount();
		Thread.sleep(5000);
		String Expected="1";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("I Click on the Flight Module")
	public void i_click_on_the_flight_module() {
		supplier.clickflight();
		String ActualTitle =driver.getTitle();
		String Expected="Flights - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		
	    
	    
	}

	@Then("I should view the flight details")
	public void i_should_view_the_flight_details() {
		boolean bool = supplier.flight();
		assertEquals(bool,true);
		driver.quit();
	}

	@When("I Click on the Visa Module")
	public void i_click_on_the_visa_module() {
	    supplier.clickvisa();
	    String ActualTitle =driver.getTitle();
		String Expected="Visa - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
	}

	@Then("I should view the Visa details")
	public void i_should_view_the_visa_details() {
		boolean bool = supplier.visa();
		assertEquals(bool,true);
		driver.quit();
	}

	@When("I Click on the Tours Module")
	public void i_click_on_the_tours_module() throws InterruptedException {
		supplier.clicktours();
		String ActualTitle =driver.getTitle();
		String Expected="Tours Management";
		assertEquals(ActualTitle,Expected);
	}

	@Then("I should view the Tour details")
	public void i_should_view_the_tour_details() {
		boolean bool = supplier.Tours();
		assertEquals(bool,true);
		driver.quit();
	}

	
	@When("I Click  the Bookings module")
	public void i_click_the_bookings_module() {
		 supplier.bookings();
		    String ActualTitle =driver.getTitle();
			String Expected="Supplier Bookings ";
			assertEquals(ActualTitle,Expected);
	}

	@Then("The Booking Module should be displayed")
	public void the_booking_module_should_be_displayed() {
		boolean bool = supplier.bookings();
		assertEquals(bool,true);
		driver.quit();
	}
}
