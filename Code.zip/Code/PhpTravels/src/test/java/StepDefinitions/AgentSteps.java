package StepDefinitions;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import pagefactory.Agent;

public class AgentSteps {
	WebDriver driver=null; 
	Agent agent;
	
	
	
	@Given("the chrome browser is open")
	public void the_chrome_browser_is_open(){
		System.setProperty("webdriver.chrome.driver","D:/javaeclipse/saucedemo/src/test/java/driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	@Then("user is on the Agent Login page")
	public void user_is_on_the_agent_login_page() {
		driver.navigate().to("https://phptravels.net/login");
		agent=new Agent(driver);
	}

	@Then("Enter the email as {string} and password as {string}")
	public void enter_the_email_as_and_password_as(String string, String string2) {
	    agent.setUsername(string);
	    agent.setPassword(string2);
	}

	@When("I Click on Login")
	public void i_click_on_login() {
	   agent.clickLogin();
	}

	@Then("I verify the login functionality with Assertion")
	public void i_verify_the_login_functionality_with_assertion() {
		String ActualTitle =driver.getTitle();
		String Expected="Login - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
		
	}
	@Then("Enter email as {string} and password as {string}.")
	public void enter_email_as_and_password_as(String string, String string2) {
		agent.setUsername(string);
	    agent.setPassword(string2);
	}

	@When("I click on the Login")
	public void i_click_on_the_login() {
		agent.clickLogin();
	}

	@Then("I could login into the Agent page")
	public void i_could_login_into_the_agent_page() {
		String ActualTitle =driver.getTitle();
		String Expected="Dashboard - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
	@When("I am logged in the Agent Website")
	public void i_am_logged_in_the_agent_website() {
		agent.setUsername("agent@phptravels.com");
	    agent.setPassword("demoagent");
	    agent.clickLogin();
	}

	@And("I click on the my Bookings")
	public void i_click_on_the_my_bookings() {
	   agent.mybookings();
	}

	@Then("I could view the booking details")
	public void i_could_view_the_booking_details() {
		String ActualTitle =driver.getTitle();
		String Expected="Bookings - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@And("I click on the my profile")
	public void i_click_on_the_my_profile() {
	    agent.myprofile();
	}

	@Then("I could view my profile")
	public void i_could_view_my_profile() {
		String ActualTitle =driver.getTitle();
		String Expected="Profile - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
@And("I click on the Addfunds")
public void I_click_on_the_Addfunds()
{
	agent.addfunds();
}
	@Then("I could view the payment page")
	public void i_could_view_the_payment_page() {
		String ActualTitle =driver.getTitle();
		String Expected="Add Funds - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@And("I click on the Logout")
	public void i_click_on_the_logout() {
	    agent.logout();
	}

	@Then("I could logout from the website")
	public void i_could_logout_from_the_website() {
		String ActualTitle =driver.getTitle();
		String Expected="Login - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}
	@When("I click on the home link")
	public void i_click_on_the_home_link() {
	   agent.destinationpage();
	}

	@Then("I am directed to the destination page")
	public void i_am_directed_to_the_destination_page() {
		String ActualTitle =driver.getTitle();
		String Expected="PHPTRAVELS | Travel Technology Partner - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("I click on the Hotel link")
	public void i_click_on_the_hotel_link() {
	    agent.hotels();
	}

	@Then("I am directed to the Hotel bookings page")
	public void i_am_directed_to_the_hotel_bookings_page() {
		String ActualTitle =driver.getTitle();
		String Expected="Search Hotels - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("I click on the tours link")
	public void i_click_on_the_tours_link() {
	    agent.tours();
	}

	@Then("I am directed to the Tours page")
	public void i_am_directed_to_the_tours_page() {
		String ActualTitle =driver.getTitle();
		String Expected="Search Tours - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("I click on the visa link")
	public void i_click_on_the_visa_link() {
	    agent.visa();
	}

	@Then("I am directed to the visa page")
	public void i_am_directed_to_the_visa_page() {
		String ActualTitle =driver.getTitle();
		String Expected="Submit Visa - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("I click on the Blog link")
	public void i_click_on_the_blog_link() {
	    agent.blog();
	}

	@Then("I am directed to the Blog page")
	public void i_am_directed_to_the_blog_page() {
		String ActualTitle =driver.getTitle();
		String Expected="Blog - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("I click on the offers link")
	public void i_click_on_the_offers_link() {
	   agent.offers();
	}

	@Then("I am directed to the offers page")
	public void i_am_directed_to_the_offers_page() {
		String ActualTitle =driver.getTitle();
		String Expected="Offers - PHPTRAVELS";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("I click on the USD")
	public void i_click_on_the_usd() {
	    agent.usd();
	}
	@Then("I Click on the INR")
	public void i_click_on_the_inr() {
		agent.ScrollDown();
	    agent.inr();
	}

	@Then("the amount is updated to INR")
	public void the_amount_is_updated_to_inr() {
		String ActualTitle =agent.getinr();
		String Expected="INR";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}

	@When("I click on the hotels")
	public void i_click_on_the_hotels() {
	    agent.hotels();
	}

	@Then("Enter the City Name as {string}")
	public void enter_the_city_name_as(String string) throws InterruptedException {
		 Thread.sleep(5000);
		agent.setCity(string);
	    Thread.sleep(5000);
	}

	@Then("Select the City")
	public void select_the_city() throws InterruptedException {
		 Thread.sleep(5000);
	    agent.cityresult();
	}

	@Then("Click on the Search button")
	public void click_on_the_search_button() throws InterruptedException {
		 Thread.sleep(5000);
	   agent.searchcity();
	}

	@Then("I could get the Hotel details in the City.")
	public void i_could_get_the_hotel_details_in_the_city() {
		String ActualTitle =driver.getTitle();
		String Expected="Hotels in thiruvananthapuram";
		assertEquals(ActualTitle,Expected);
		driver.quit();
	}


}
